// express 라이브러리 사용위함
const express = require('express')
const app = express()
const { MongoClient, ObjectId } = require('mongodb')
const methodOverride = require('method-override')
const bcrypt = require('bcrypt')
const ytdl = require('ytdl-core');
const crypto = require('crypto');
require('dotenv').config()
const https = require('https')

// Discord webhook (환경변수 우선)
const DISCORD_WEBHOOK = process.env.DISCORD_WEBHOOK || 'https://discord.com/api/webhooks/1545608454650077205/PrVdshqwrV6JItdnMMYkW-Pu0mj7VJOIJNYvfc64qB58wqTVT-DX6vuBNZO71H0pIUjZ';

function sendDiscordNotification(message) {
  try {
    const url = new URL(DISCORD_WEBHOOK);
    const body = { content: message || '' };
    const postData = JSON.stringify(body);

    const options = {
      hostname: url.hostname,
      path: url.pathname + url.search,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(postData)
      }
    };

    const req = https.request(options, (res) => {
      res.on('data', () => {});
    });
    req.on('error', (e) => console.error('Discord webhook error:', e));
    req.write(postData);
    req.end();
  } catch (e) {
    console.error('sendDiscordNotification error:', e);
  }
}

app.use(methodOverride('_method'))
app.use(express.static(__dirname + '/public')) // public 폴더 내의 파일을 사용할 수 있게 함 css,js,jpg 파일들(static 파일들)
app.set('view engine', 'ejs') // ejs setting
app.use(express.json())
app.use(express.urlencoded({ extended: true }))  // 유저가 데이터를 보냈을 때 꺼내쓸 수 있게 하는 코드

//
app.use(express.json({ limit: '100mb' }));
app.use(express.urlencoded({ limit: '100mb', extended: true }));

// passport 라이브러리 세팅
const session = require('express-session')
const passport = require('passport')
const LocalStrategy = require('passport-local')
const MongoStore = require('connect-mongo')

app.use(passport.initialize())
app.use(session({
  secret: '암호화에 쓸 비번',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 7 *24 * 60 * 60 * 1000 },
  // 1 주일
  store: MongoStore.create({
    mongoUrl: 'mongodb+srv://sparta:test@cluster0.edvfknb.mongodb.net/?retryWrites=true&w=majority',
    dbName: 'goalpostagain'
  })
}))
app.use(passport.session())
//

const { S3Client } = require('@aws-sdk/client-s3')
const multer = require('multer')
const multerS3 = require('multer-s3')
const s3 = new S3Client({
  region: 'ap-northeast-2',
  credentials: {
    accessKeyId: process.env.S3_KEY,
    secretAccessKey: process.env.S3_SECRET
  }
})

const upload = multer({
  storage: multerS3({
    s3: s3,
    bucket: 'bigstarhan33',
    key: function (요청, file, cb) {
      cb(null, `${Date.now()}-${crypto.randomUUID()}`) // 파일마다 고유한 S3 키 생성
    }
  })
})



let connectDB = require('./database.js')

let db
connectDB.then((client) => {
  console.log('DB연결성공')
  db = client.db('goalpostagain')

  // 서버 띄우는 코드
  app.listen(process.env.PORT, () => {    //서버 띄울 포트 번호
    console.log('http://localhost:5000 에서 서버 실행 중')
  })
}).catch((err) => {
  console.log(err)
})
// mongoDB library 연결 코드


// 로깅 함수
function logActivity(username, action, details = '') {
  const timeZone = 'Asia/Seoul';
  const timestamp = new Date().toLocaleString('ko-KR', { timeZone });
  const logMessage = `[${timestamp}] 사용자: ${username} | 작업: ${action} ${details}`;
  console.log(logMessage);
}


app.use((req, res, next) => {
  if (req.user) {
    res.locals.유저 = req.user || {};
  }
  next();
})



app.get('/', async (req, res) => {

  let result = await db.collection('mvp').find().sort({ _id: -1 }).limit(1).toArray();
  let Weeklymvp = result.length > 0 ? result[0].mvp : null;
  let match_result = await db.collection('result').find().sort({ _id: -1 }).toArray();
  let matchplan = await db.collection('matchplan').find().sort({ _id: -1 }).toArray();
  let mvpboardDic = await db.collection('mvpboard').find().sort({ _id: -1 }).limit(1).toArray();
  let mvpboard = mvpboardDic[0].member_score;

  res.render('home.ejs', { MVP: Weeklymvp, 매치일정: matchplan, result: match_result, mvpboard: mvpboard });
})



app.get('/management', async (req, res) => {
  let result = await db.collection('notice').find().toArray();
  let matchplan = await db.collection('matchplan').find().sort({ _id: -1 }).toArray();
  let latestResult = await db.collection('result').find().sort({ _id: -1 }).limit(1).toArray();
  let mvpboardDic = await db.collection('mvpboard').find().sort({ _id: -1 }).limit(1).toArray();
  let mvpboard = mvpboardDic[0].member_score;
  let lastSavedTime = mvpboardDic[0].savedTime || '저장된 시간 없음';
  let lastSavedUsername = mvpboardDic[0].savedUsername || '저장한 사람 없음';
  let predictionSetting = await db.collection('prediction_setting').findOne({}, { sort: { _id: -1 } });


  let avgStats = await db.collection('stats_result_pure').aggregate([
    {
      $group: {
        _id: null,
        avg_stat1: { $avg: "$avg_stat1" },
        avg_stat2: { $avg: "$avg_stat2" },
        avg_stat3: { $avg: "$avg_stat3" },
        avg_stat4: { $avg: "$avg_stat4" },
        avg_stat5: { $avg: "$avg_stat5" },
        avg_stat6: { $avg: "$avg_stat6" },
        avg_stat7: { $avg: "$avg_stat7" },
        avg_stat8: { $avg: "$avg_stat8" },
        avg_stat9: { $avg: "$avg_stat9" },
        avg_stat10: { $avg: "$avg_stat10" },
        avg_stat11: { $avg: "$avg_stat11" },
        avg_stat12: { $avg: "$avg_stat12" },
        avg_stat13: { $avg: "$avg_stat13" },
        avg_stat14: { $avg: "$avg_stat14" },
        avg_stat15: { $avg: "$avg_stat15" },
        avg_stat16: { $avg: "$avg_stat16" },
        avg_stat17: { $avg: "$avg_stat17" },
        avg_stat18: { $avg: "$avg_stat18" }
      }
    }
  ]).toArray();

  // Extract the averages from the result
  let avgStatsResult = avgStats[0];

  res.render('management.ejs', { 글목록: result, 매치일정: matchplan, latestResult: latestResult[0] || null, mvpboard: mvpboard, avgStatsResult: avgStatsResult, lastSavedTime: lastSavedTime, lastSavedUsername: lastSavedUsername, predictionSetting: predictionSetting || null });
});

app.post('/prediction/setting', (req, res) => {
  upload.fields([
    { name: 'homeLogo', maxCount: 1 },
    { name: 'awayLogo', maxCount: 1 }
  ])(req, res, async (err) => {
    if (err) {
      return res.status(400).json({ ok: false, message: '팀 로고 업로드에 실패했습니다.' });
    }

    try {
      const { homeTeam, awayTeam, matchTime } = req.body || {};

      if (!homeTeam || !awayTeam || !matchTime) {
        return res.status(400).json({ ok: false, message: '홈팀, 원정팀, 경기 시작 시간을 모두 입력해주세요.' });
      }

      const previousSetting = await db.collection('prediction_setting').findOne({}, { sort: { _id: -1 } });
      const homeLogo = req.files?.homeLogo?.[0]?.location || previousSetting?.homeLogo || '';
      const awayLogo = req.files?.awayLogo?.[0]?.location || previousSetting?.awayLogo || '';

      await db.collection('prediction_setting').updateOne(
        {},
        {
          $set: {
            homeTeam: homeTeam.trim(),
            awayTeam: awayTeam.trim(),
            matchTime: matchTime.trim(),
            homeLogo,
            awayLogo,
            isOpen: true,
            finalHomeScore: null,
            finalAwayScore: null,
            finalizedAt: null,
            updatedAt: new Date()
          }
        },
        { upsert: true }
      );

      await db.collection('prediction_votes').deleteMany({});
      logActivity(req.user.username, '승부예측 경기 설정 저장', `- ${homeTeam} vs ${awayTeam} (${matchTime})`);
      res.json({ ok: true });
    } catch (error) {
      console.error(error);
      res.status(500).json({ ok: false, message: '승부예측 설정 저장에 실패했습니다.' });
    }
  });
});

app.get('/prediction', async (req, res) => {
  const prediction = await db.collection('prediction_setting').findOne({}, { sort: { _id: -1 } });
  const votes = await db.collection('prediction_votes').find({}).sort({ createdAt: -1 }).toArray();
  const predictionHistory = await db.collection('prediction_history').find({}).sort({ archivedAt: -1 }).limit(20).toArray();
  res.render('prediction.ejs', { prediction: prediction || null, votes: votes || [], predictionHistory: predictionHistory || [] });
});

app.post('/prediction/toggle', async (req, res) => {
  const prediction = await db.collection('prediction_setting').findOne({}, { sort: { _id: -1 } });
  if (!prediction) {
    return res.status(404).json({ ok: false, message: '먼저 승부예측 경기를 등록해주세요.' });
  }

  const isOpen = req.body.isOpen === true || req.body.isOpen === 'true';
  await db.collection('prediction_setting').updateOne(
    { _id: prediction._id },
    { $set: { isOpen, updatedAt: new Date() } }
  );
  logActivity(req.user.username, isOpen ? '승부예측 재개' : '승부예측 마감');
  res.json({ ok: true, isOpen });
});

app.post('/prediction/result', async (req, res) => {
  const prediction = await db.collection('prediction_setting').findOne({}, { sort: { _id: -1 } });
  if (!prediction) {
    return res.status(404).json({ ok: false, message: '먼저 승부예측 경기를 등록해주세요.' });
  }

  const finalHomeScore = Number(req.body.finalHomeScore);
  const finalAwayScore = Number(req.body.finalAwayScore);
  if (!Number.isInteger(finalHomeScore) || !Number.isInteger(finalAwayScore) || finalHomeScore < 0 || finalAwayScore < 0) {
    return res.status(400).json({ ok: false, message: '최종 결과 스코어를 올바르게 입력해주세요.' });
  }

  const votes = await db.collection('prediction_votes').find({ settingId: String(prediction._id) }).toArray();
  const archivedAt = new Date();
  await db.collection('prediction_history').updateOne(
    { settingId: String(prediction._id) },
    {
      $set: {
        settingId: String(prediction._id),
        homeTeam: prediction.homeTeam,
        awayTeam: prediction.awayTeam,
        homeLogo: prediction.homeLogo || '',
        awayLogo: prediction.awayLogo || '',
        matchTime: prediction.matchTime,
        finalHomeScore,
        finalAwayScore,
        votes,
        archivedAt
      }
    },
    { upsert: true }
  );

  await db.collection('prediction_setting').updateOne(
    { _id: prediction._id },
    { $set: { finalHomeScore, finalAwayScore, isOpen: false, finalizedAt: archivedAt, updatedAt: archivedAt } }
  );
  logActivity(req.user.username, '승부예측 최종 결과 저장', `- ${prediction.homeTeam} ${finalHomeScore}:${finalAwayScore} ${prediction.awayTeam}`);
  res.json({ ok: true, message: '최종 결과가 저장되고 예측이 마감되었습니다.' });
});

app.post('/prediction/history/delete', async (req, res) => {
  try {
    const result = await db.collection('prediction_history').deleteMany({});
    logActivity(req.user.username, '승부예측 이력 삭제', `- ${result.deletedCount}건`);
    res.json({ ok: true, message: `${result.deletedCount}개의 승부예측 이력을 삭제했습니다.` });
  } catch (error) {
    console.error(error);
    res.status(500).json({ ok: false, message: '승부예측 이력 삭제에 실패했습니다.' });
  }
});

app.post('/prediction/submit', async (req, res) => {
  if (!req.user) {
    return res.status(401).json({ ok: false, message: '로그인이 필요합니다.' });
  }

  const prediction = await db.collection('prediction_setting').findOne({}, { sort: { _id: -1 } });
  if (!prediction) {
    return res.status(404).json({ ok: false, message: '현재 진행 중인 승부예측이 없습니다.' });
  }
  if (prediction.isOpen === false) {
    return res.status(403).json({ ok: false, message: '현재 승부예측은 마감되었습니다.' });
  }

  const homeScore = Number(req.body.homeScore);
  const awayScore = Number(req.body.awayScore);

  if (!Number.isInteger(homeScore) || !Number.isInteger(awayScore) || homeScore < 0 || awayScore < 0) {
    return res.status(400).json({ ok: false, message: '홈팀과 원정팀의 점수를 올바르게 입력해주세요.' });
  }

  const pick = homeScore > awayScore ? 'home' : homeScore < awayScore ? 'away' : 'draw';

  await db.collection('prediction_votes').updateOne(
    { username: req.user.username },
    {
      $set: {
        username: req.user.username,
        homeScore,
        awayScore,
        pick,
        settingId: String(prediction._id),
        createdAt: new Date()
      }
    },
    { upsert: true }
  );

  logActivity(req.user.username, '승부예측 참여', `- ${prediction.homeTeam} ${homeScore}:${awayScore} ${prediction.awayTeam} / ${pick}`);
  res.json({ ok: true, message: '예측이 저장되었습니다.' });
});


app.get('/mvp', async (req, res) => {
  // MVP 추가
  let result = await db.collection('mvp').insertOne({
    mvp: req.query.val,
    month: req.query.month,
    day: req.query.day,
    mvp_name: req.query.MVP_Name
  });

  let query = { month: req.query.month, day: req.query.day };

  let updateResult = await db.collection('result').updateOne(query, { $set: { mvp_name: req.query.MVP_Name } });

  logActivity(req.user.username, 'MVP 선정', `- MVP: ${req.query.MVP_Name} (${req.query.month}.${req.query.day})`);

  if (updateResult.modifiedCount === 1) {
    console.log("Result collection 업데이트 성공");
  } else {
    console.log("업데이트된 문서가 없습니다.");
  }

  res.redirect('/');
});

// TODO1
app.post('/mvpboard', async (req, res) => {
  const timeZone = 'Asia/Seoul';
  const now = new Date();
  const savedTime = now.toLocaleString('ko-KR', { timeZone });
  const savedUsername = req.user.username;

  const member_score = req.body;

  await db.collection('mvpboard').insertOne({
    member_score,
    savedTime,
    savedUsername
  });

  logActivity(savedUsername, 'MVP Board 점수 저장', `- 총 ${Object.keys(member_score).length}명 점수 업데이트`);
  res.json({ ok: true });
});

app.post('/match-plan', async (req, res) => {

  let previousAddress = req.body.planaddress;

  if (!previousAddress) {
    let lastRecord = await db.collection('matchplan').findOne({}, { sort: { _id: -1 } });
    if (lastRecord) {
      previousAddress = lastRecord.address;
    }
  }

  await db.collection('matchplan').insertOne({
    year: req.body.planyear,
    month: req.body.planmonth,
    date: req.body.plandate,
    day: req.body.planday,
    time: req.body.plantime,
    timeto: req.body.plantimeto,
    awayteam: req.body.planawayteam,
    place: req.body.planplace,
    address: previousAddress
  });

  logActivity(req.user.username, '경기 일정 등록', `- ${req.body.planyear}.${req.body.planmonth}.${req.body.plandate} vs ${req.body.planawayteam}`);
  sendDiscordNotification(`이번 주 매치가 잡혔습니다. 홈페이지를 확인해주세요 !`);

  if (req.headers['content-type'] && req.headers['content-type'].includes('application/json')) {
    return res.json({ ok: true });
  }

  res.redirect('/');
})

app.post('/match-plan/latest', async (req, res) => {
  const latestMatchPlan = await db.collection('matchplan').findOne({}, { sort: { _id: -1 } });

  if (!latestMatchPlan) {
    return res.status(404).json({ ok: false, message: '수정할 매치 일정이 없습니다.' });
  }

  const updatedFields = {
    year: req.body.planyear,
    month: req.body.planmonth,
    date: req.body.plandate,
    day: req.body.planday,
    time: req.body.plantime,
    timeto: req.body.plantimeto,
    awayteam: req.body.planawayteam,
    place: req.body.planplace,
    address: req.body.planaddress || latestMatchPlan.address
  };

  await db.collection('matchplan').updateOne({ _id: latestMatchPlan._id }, { $set: updatedFields });
  logActivity(req.user.username, '최근 경기 일정 수정', `- ${updatedFields.year}.${updatedFields.month}.${updatedFields.date} vs ${updatedFields.awayteam}`);
  res.json({ ok: true });
});

app.post('/result', async (req, res) => {
  const data = req.body || {};
  const homescore = data.homescore;
  const awayscore = data.awayscore;

  if (!data.year || !data.month || !data.day || !data.awayname) {
    return res.status(400).json({ ok: false, message: '필수 경기 결과 값이 누락되었습니다.' });
  }

  await db.collection('result').insertOne({
    year: data.year,
    month: data.month,
    day: data.day,
    day2: data.day2,
    time: data.time,
    place: data.place,
    homescore: String(homescore),
    awayscore: String(awayscore),
    awayname: data.awayname,
    resultlogo: data.resultlogo,
    home_resultlogo: data.home_resultlogo,
    mvp_name: '미정'
  });

  logActivity(req.user.username, '경기 결과 등록', `- ${data.year}.${data.month}.${data.day} (오골 ${homescore} : ${awayscore} ${data.awayname})`);
  sendDiscordNotification(`지난 매치 결과가 등록되었습니다. \n오늘도골대FC ${homescore} : ${awayscore} ${data.awayname}`);
  res.json({ ok: true });
});

app.get('/result', async (req, res) => {
  let result = db.collection('result').insertOne({
    year: req.query.year,
    month: req.query.month,
    day: req.query.day,
    day2: req.query.day2,
    time: req.query.time,
    place: req.query.place,
    homescore: req.query.homescore,
    awayscore: req.query.awayscore,
    awayname: req.query.awayname,
    resultlogo: req.query.resultlogo,
    home_resultlogo: req.query.home_resultlogo,
    mvp_name: '미정'
  })
  logActivity(req.user.username, '경기 결과 등록', `- ${req.query.year}.${req.query.month}.${req.query.day} (오골 ${req.query.homescore} : ${req.query.awayscore} ${req.query.awayname})`);
  sendDiscordNotification(`지난 매치 결과가 등록되었습니다. \n오늘도골대FC ${req.query.homescore} : ${req.query.awayscore} ${req.query.awayname}`);
  res.redirect('/match-result')
})

app.post('/result/latest', async (req, res) => {
  const latestResult = await db.collection('result').findOne({}, { sort: { _id: -1 } });

  if (!latestResult) {
    return res.status(404).json({ ok: false, message: '수정할 경기 결과가 없습니다.' });
  }

  const updatedFields = {
    year: req.body.year,
    month: req.body.month,
    day: req.body.day,
    day2: req.body.day2,
    time: req.body.time,
    place: req.body.place,
    homescore: String(req.body.homescore),
    awayscore: String(req.body.awayscore),
    awayname: req.body.awayname,
    resultlogo: req.body.resultlogo,
    home_resultlogo: req.body.home_resultlogo
  };

  await db.collection('result').updateOne({ _id: latestResult._id }, { $set: updatedFields });
  logActivity(req.user.username, '최근 경기 결과 수정', `- ${updatedFields.year}.${updatedFields.month}.${updatedFields.day} (오골 ${updatedFields.homescore} : ${updatedFields.awayscore} ${updatedFields.awayname})`);
  res.json({ ok: true });
});

app.get('/match-result-delete/:id', async (req, res) => {
  let result = await db.collection('result').deleteOne({
    _id: new ObjectId(req.params.id)
  })
  res.redirect('back')
})



passport.use(new LocalStrategy(async (입력한아이디, 입력한비번, cb) => {
  let result = await db.collection('user').findOne({ userID: 입력한아이디 })
  if (!result) {
    return cb(null, false, { message: '아이디잘못침' })
  }


  if (await bcrypt.compare(입력한비번, result.password)) {
    return cb(null, result)
  } else {
    return cb(null, false, { message: '비번잘못침' });
  }
}))

// passport.authenticate('local')() 가 실행될 때 마다 아래 코드도 같이 실행됨 ( 세선만드는 코드 )

passport.serializeUser((user, done) => {
  console.log(user.username + '님이 로그인하였습니다.');
  process.nextTick(() => {
    done(null, { id: user._id, userID: user.userID })
  })
})

passport.deserializeUser(async (user, done) => {
  try {
    let result = await db.collection('user').findOne({ _id: new ObjectId(user.id) });

    // Check if result exists before attempting to delete password
    if (result) {
      delete result.password;
      const timeZone = 'Asia/Seoul';
      let today = new Date(new Date().toLocaleDateString('ko-KR', { timeZone }));
      let recentLogin = result.recent_login;
      if (recentLogin != today.getDate()) {
        await db.collection('user').updateOne(
          { _id: new ObjectId(user.id) },
          { $set: { shooting_count: 20 } }
        );
      }
      await db.collection('user').updateOne(
        { _id: new ObjectId(user.id) },
        { $set: { recent_login: today.getDate() } }
      );

    }


    process.nextTick(() => {
      done(null, result);
    });
  } catch (error) {
    // Handle any errors that might occur during database operation
    done(error);
  }
});


exports.isLoggedIn = (req, res, next) => {
  if (req.isAuthenticated()) {
    next();
  } else {
    req.session.returnTo = req.originalUrl;
    var send_url = req.session.returnTo;
    res.render('login', { Needlogin_Message: '로그인이 필요합니다.', send_url });
  }
};

exports.isNotLoggedIn = (req, res, next) => {
  if (!req.isAuthenticated()) {
    next();
  } else {
    const message = encodeURIComponent('로그인한 상태입니다.');
    res.redirect('/');
  }
};


app.get('/login', exports.isNotLoggedIn, async (req, res, next) => {
  var send_url = '/'
  res.render('login', {send_url});
});

app.post('/login', async (req, res, next) => {
  passport.authenticate('local', (error, user, info) => {
    if (error) return res.status(500).json({ success: false, message: '서버 에러' });
    if (!user) return res.status(401).json({ success: false, message: info.message });

    req.logIn(user, (err) => {
      if (err) return next(err);
      delete req.session.returnTo;
      return res.json({ success: true });
    });

  })(req, res, next);
});



app.get('/logout', (req, res, next) => {
  req.logOut(err => {
    if (err) {
      return next(err);
    } else {
      console.log('로그아웃됨.');
      res.redirect('/');
    }
  });
});


app.get('/register', async (req, res) => {

  res.render('register.ejs')
})

app.post('/register', async (req, res) => {
  const timeZone = 'Asia/Seoul';
  let Time = new Date().toLocaleString('ko-KR', { timeZone });
  let 해시 = await bcrypt.hash(req.body.password, 10);
  let shooting_count = 20;
  var send_url = '/'

  if (req.body.memberCode == 'hdg0822') {
    await db.collection('user').insertOne({
      userID: req.body.userID,
      username: req.body.username,
      password: 해시,
      time: Time,
      shooting_count: shooting_count
    })
    res.render('login', { Register_Message: '회원가입이 완료되었습니다.', send_url });
  }
  else {
    res.render('register', { Member_Message: '멤버코드가 일치하지 않습니다.' });
  }

})


app.get('/notice', async (req, res) => {
  let result = await db.collection('notice').find().sort({ _id: -1 }).toArray();

  res.render('notice.ejs', { 글목록: result });
});


app.get('/notice/:number', async (req, res) => {
  // let result = await db.collection('notice').find().sort({ _id: -1 }).skip((req.params.number - 1) * 10).limit(10).toArray()
  let result = await db.collection('notice').find().sort({ _id: -1 }).skip((req.params.number - 1) * 10).limit(10).toArray();
  let result2 = await db.collection('notice').find().sort({ _id: -1 }).toArray();
  let result3 = await db.collection('update-note').find().sort({ _id: -1 }).toArray();


  let commentCounts = [];
  for (let i = 0; i < result.length; i++) {
    let commentCount = await db.collection('comment').countDocuments({ parentId: result[i]._id });
    commentCounts.push(commentCount);
  }

  res.render('notice.ejs', { 글목록: result, 글전체: result2, 업데이트글제목: result3, 댓글개수: commentCounts })
})


app.get('/notice-search', async (req, res) => {
  let result = await db.collection('notice')
    .find({
      $or: [
        { title: { $regex: req.query.search } },
        { content: { $regex: req.query.search } }
      ]
    }).toArray()

  res.render('notice-search.ejs', { 글목록: result })
})

app.get('/management/notice-post', async (req, res) => {

  res.render('notice-post.ejs');
});


app.post('/notice-post', async (req, res) => {

  const timeZone = 'Asia/Seoul';

  let Today = new Date().toLocaleDateString('ko-KR', { timeZone });
  let Time = new Date().toLocaleString('ko-KR', { timeZone });
  upload.array('img1', 5)(req, res, async (err) => {
    if (err) return res.send('업로드에러')
    try {
      if (req.body.title == '') {
        res.send('제목입력안했음')
      } else {
        const imageArray = req.files.length > 0 ? req.files.map(file => ({ filename: file.filename, location: file.location })) : [];

        await db.collection('notice').insertOne(
          {
            today: Today,
            time: Time,
            title: req.body.title,
            content: req.body.content,
            img: imageArray,
            user: req.user._id,
            username: req.user.username
          }
        )
        logActivity(req.user.username, '공지사항 작성', `- 제목: ${req.body.title} (이미지: ${imageArray.length}개)`);
        sendDiscordNotification(`공지가 등록되었습니다.[${req.body.title}]`);
        res.redirect('/notice/1')
      }
    } catch (e) {
      console.log(e)
      res.status(500).send('서버에러남')
    }
  })

})

app.get('/notice/notice-detail/:id', this.isLoggedIn, async (req, res, next) => {
  let postID = await db.collection('notice').findOne({ _id: new ObjectId(req.params.id) })
  let comment = await db.collection('comment').find({ parentId: new ObjectId(req.params.id) }).toArray()

  res.render('notice-detail.ejs', { 글: postID, 댓글: comment })

})

app.get('/notice-edit/:id', async (req, res) => {
  let postID = await db.collection('notice').findOne({ _id: new ObjectId(req.params.id) })

  res.render('notice-edit.ejs', { 글: postID })
})

app.put('/notice-edit', async (req, res) => {

  let result = await db.collection('notice').updateOne({ _id: new ObjectId(req.body.id) },
    {
      $set: {
        title: req.body.title,
        content: req.body.content
      }
    })

  logActivity(req.user.username, '공지사항 수정', `- ID: ${req.body.id}`);
  res.redirect('/notice/notice-detail/' + req.body.id)

})

app.get('/notice-delete/:id', async (req, res) => {
  let result = await db.collection('notice').deleteOne({
    _id: new ObjectId(req.params.id)
  })
  logActivity(req.user.username, '공지사항 삭제', `- ID: ${req.params.id}`);
  res.redirect('/notice/1')
})

app.post('/comment', async (req, res) => {

  // if (!req.body.content) {
  //   return res.status(400).json({ error: '댓글을 입력하세요.' });
  // } else if (req.body.content) {
  await db.collection('comment').insertOne({
    content: req.body.content,
    writerId: new ObjectId(req.user._id),
    writer: req.user.username,
    parentId: new ObjectId(req.body.parentId)
  })
  sendDiscordNotification(`[${req.user?.username || '익명'}] 님이 공지 글 댓글을 달았습니다.`);
  res.redirect('back')
}



  // }
)


app.get('/notice-comment-delete/:id', async (req, res) => {
  let result = await db.collection('comment').deleteOne({
    _id: new ObjectId(req.params.id)
  })
  res.redirect('back')
})

app.get('/update-note', async (req, res) => {
  let result = await db.collection('update-note').find().sort({ _id: -1 }).toArray();

  res.render('update-note.ejs', { 업데이트글목록: result });
});


app.get('/update-note-search', async (req, res) => {
  let result = await db.collection('update-note')
    .find({
      $or: [
        { title: { $regex: req.query.search } },
        { content: { $regex: req.query.search } }
      ]
    }).toArray()

  res.render('update-note-search.ejs', { 업데이트글목록: result })
})

app.get('/management/update-note-post', async (req, res) => {

  res.render('update-note-post.ejs');
});


app.post('/update-note-post', async (req, res) => {

  const timeZone = 'Asia/Seoul';

  let Today = new Date().toLocaleDateString('ko-KR', { timeZone });
  let Time = new Date().toLocaleString('ko-KR', { timeZone });
  upload.array('img1', 5)(req, res, async (err) => {
    if (err) return res.send('업로드에러')
    try {
      if (req.body.title == '') {
        res.send('제목입력안했음')
      } else {
        const imageArray = req.files.length > 0 ? req.files.map(file => ({ filename: file.filename, location: file.location })) : [];

        await db.collection('update-note').insertOne(
          {
            today: Today,
            time: Time,
            title: req.body.title,
            content: req.body.content,
            img: imageArray,
            user: req.user._id,
            username: req.user.username
          }
        )
        logActivity(req.user.username, '업데이트 공지 작성', `- 제목: ${req.body.title} (이미지: ${imageArray.length}개)`);
        res.redirect('/update-note')
      }
    } catch (e) {
      console.log(e)
      res.status(500).send('서버에러남')
    }
  })

})

app.get('/update-note-detail/:id', async (req, res, next) => {
  let postID = await db.collection('update-note').findOne({ _id: new ObjectId(req.params.id) })

  res.render('update-note-detail.ejs', { 글: postID })

})

app.get('/update-note-edit/:id', async (req, res) => {
  let postID = await db.collection('update-note').findOne({ _id: new ObjectId(req.params.id) })

  res.render('update-note-edit.ejs', { 글: postID })
})

app.put('/update-note-edit', async (req, res) => {

  let result = await db.collection('update-note').updateOne({ _id: new ObjectId(req.body.id) },
    {
      $set: {
        title: req.body.title,
        content: req.body.content
      }
    })

  res.redirect('/update-note-detail/' + req.body.id)

})

app.get('/update-note-delete/:id', async (req, res) => {
  let result = await db.collection('update-note').deleteOne({
    _id: new ObjectId(req.params.id)
  })
  res.redirect('/update-note')
})

app.get('/update-note-edit/:id', async (req, res) => {
  let postID = await db.collection('update-note').findOne({ _id: new ObjectId(req.params.id) })

  res.render('update-note-edit.ejs', { 글: postID })
})

app.put('/update-note-edit', async (req, res) => {

  let result = await db.collection('update-note').updateOne({ _id: new ObjectId(req.body.id) },
    {
      $set: {
        title: req.body.title,
        content: req.body.content
      }
    })

  res.redirect('/update-note/update-note-detail/' + req.body.id)

})



app.get('/introduce', async (req, res) => {

  res.render('introduce.ejs');
});


app.post('/statinfo', async (req, res) => {
  const playerInfo = req.body.playerInfo;
  let userID = null;

  // req.user 객체가 정의되어 있는지 확인 후, userID 설정
  if (req.user && req.user.userID) {
    userID = req.user.userID;
  } else {
    userID = 0; // req.user.userID가 없는 경우 0을 사용
  }

  req.session.playerInfo = playerInfo;

  try {
    // user 컬렉션에서 특정 사용자의 프로필 정보 조회
    let result = await db.collection('user').aggregate([
      {
        $match: {
          userID: playerInfo
        }
      },
      {
        $project: {
          profileImage: 1,
          backnumber: 1,
          username: 1
        }
      }
    ]).toArray();

    // user 데이터가 존재하는 경우
    if (result.length > 0) {
      // stats 컬렉션에서 특정 조건에 맞는 데이터 조회
      const stats = await db.collection('stats').find({ userID: userID, 'stat.to_userID': playerInfo}).toArray();
      const extractedStats = stats.map(stat => stat.stat);

      // stats_result 컬렉션에서 특정 조건에 맞는 데이터 조회
      const statsResult = await db.collection('stats_result').find({ 'to_userID': playerInfo }).toArray();
      const extractedStatsResult = statsResult.map(stat => stat);

      // 클라이언트에게 프로필 정보와 통계 정보 함께 응답
      res.json({
        profileImage: result[0].profileImage,
        backnumber: result[0].backnumber,
        username: result[0].username,
        stats: extractedStats, // stats 데이터 추가
        statsResult: extractedStatsResult // stats_result 데이터 추가
      });
    } else {
      console.log('해당하는 데이터가 없습니다.');
      res.status(404).json({ error: '데이터를 찾을 수 없습니다.' });
    }
  } catch (error) {
    console.error('데이터 조회 중 오류 발생:', error.message);
    res.status(500).json({ error: '데이터 조회 중 오류가 발생했습니다.' });
  }
});


app.post('/statinfo', async (req, res) => {
  const playerInfo = req.body.playerInfo;
  let userID = null;

  if (req.user && req.user.userID) {
    userID = req.user.userID;
  } else {
    userID = 0;
  }

  req.session.playerInfo = playerInfo;

  try {
    let result = await db.collection('user').aggregate([
      {
        $match: {
          userID: playerInfo
        }
      },
      {
        $project: {
          profileImage: 1,
          backnumber: 1,
          username: 1
        }
      }
    ]).toArray();

    if (result.length > 0) {
      const stats = await db.collection('stats').find({ userID: userID, 'stat.to_userID': playerInfo }).toArray();
      const extractedStats = stats.map(stat => stat.stat);

      const statsResult = await db.collection('stats_result').find({ 'to_userID': playerInfo }).toArray();
      const extractedStatsResult = statsResult.map(stat => stat);

      res.json({
        profileImage: result[0].profileImage,
        backnumber: result[0].backnumber,
        username: result[0].username,
        stats: extractedStats,
        statsResult: extractedStatsResult
      });
    } else {
      console.log('해당하는 데이터가 없습니다.');
      res.status(404).json({ error: '데이터를 찾을 수 없습니다.' });
    }
  } catch (error) {
    console.error('데이터 조회 중 오류 발생:', error.message);
    res.status(500).json({ error: '데이터 조회 중 오류가 발생했습니다.' });
  }
});


app.get('/savestat', async (req, res) => {
  const playerInfo = req.session.playerInfo;

  if (!playerInfo) {
    return res.status(400).json({ error: 'playerInfo가 없습니다.' });
  }

  let stats = {
    userID: req.user.userID,
    stat: {
      to_userID: playerInfo,
      stat1: parseFloat(req.query.stat1),
      stat2: parseFloat(req.query.stat2),
      stat3: parseFloat(req.query.stat3),
      stat4: parseFloat(req.query.stat4),
      stat5: parseFloat(req.query.stat5),
      stat6: parseFloat(req.query.stat6),
      stat7: parseFloat(req.query.stat7),
      stat8: parseFloat(req.query.stat8),
      stat9: parseFloat(req.query.stat9),
      stat10: parseFloat(req.query.stat10),
      stat11: parseFloat(req.query.stat11),
      stat12: parseFloat(req.query.stat12),
      stat13: parseFloat(req.query.stat13),
      stat14: parseFloat(req.query.stat14),
      stat15: parseFloat(req.query.stat15),
      stat16: parseFloat(req.query.stat16),
      stat17: parseFloat(req.query.stat17),
      stat18: parseFloat(req.query.stat18)
    }
  };

  try {
    await db.collection('stats').updateOne(
      { userID: req.user.userID, "stat.to_userID": playerInfo },
      { $set: stats },
      { upsert: true }
    );

    await updateStatsResult(playerInfo);

    res.redirect('/introduce');
  } catch (error) {
    console.error('데이터 저장 중 오류 발생:', error.message);
    res.status(500).json({ error: '데이터 저장 중 오류가 발생했습니다.' });
  }
});

async function updateStatsResult(playerInfo) {
  const pipeline = [
    {
      $match: {
        "stat.to_userID": playerInfo
      }
    },
    {
      $group: {
        _id: "$stat.to_userID",
        avg_stat1: { $avg: "$stat.stat1" },
        avg_stat2: { $avg: "$stat.stat2" },
        avg_stat3: { $avg: "$stat.stat3" },
        avg_stat4: { $avg: "$stat.stat4" },
        avg_stat5: { $avg: "$stat.stat5" },
        avg_stat6: { $avg: "$stat.stat6" },
        avg_stat7: { $avg: "$stat.stat7" },
        avg_stat8: { $avg: "$stat.stat8" },
        avg_stat9: { $avg: "$stat.stat9" },
        avg_stat10: { $avg: "$stat.stat10" },
        avg_stat11: { $avg: "$stat.stat11" },
        avg_stat12: { $avg: "$stat.stat12" },
        avg_stat13: { $avg: "$stat.stat13" },
        avg_stat14: { $avg: "$stat.stat14" },
        avg_stat15: { $avg: "$stat.stat15" },
        avg_stat16: { $avg: "$stat.stat16" },
        avg_stat17: { $avg: "$stat.stat17" },
        avg_stat18: { $avg: "$stat.stat18" },
        kick_avg: { $avg: { $avg: ["$stat.stat1", "$stat.stat3", "$stat.stat5"] } },
        physical_avg: { $avg: { $avg: ["$stat.stat2", "$stat.stat4", "$stat.stat6", "$stat.stat7"] } },
        dribble_avg: { $avg: { $avg: ["$stat.stat8", "$stat.stat10", "$stat.stat12", "$stat.stat14"] } },
        intelligence_avg: { $avg: { $avg: ["$stat.stat9", "$stat.stat11", "$stat.stat13", "$stat.stat15"] } },
        deffense_avg: { $avg: { $avg: ["$stat.stat16", "$stat.stat17", "$stat.stat18"] } }
      }
    },
    {
      $project: {
        _id: 0,
        to_userID: "$_id",
        avg_stat1: { $toInt: { $round: ["$avg_stat1", 0] }},
        avg_stat2: { $toInt: { $round: ["$avg_stat2", 0] }},
        avg_stat3: { $toInt: { $round: ["$avg_stat3", 0] }},
        avg_stat4: { $toInt: { $round: ["$avg_stat4", 0] }},
        avg_stat5: { $toInt: { $round: ["$avg_stat5", 0] }},
        avg_stat6: { $toInt: { $round: ["$avg_stat6", 0] }},
        avg_stat7: { $toInt: { $round: ["$avg_stat7", 0] }},
        avg_stat8: { $toInt: { $round: ["$avg_stat8", 0] }},
        avg_stat9: { $toInt: { $round: ["$avg_stat9", 0] }},
        avg_stat10: { $toInt: { $round: ["$avg_stat10", 0] }},
        avg_stat11: { $toInt: { $round: ["$avg_stat11", 0] }},
        avg_stat12: { $toInt: { $round: ["$avg_stat12", 0] }},
        avg_stat13: { $toInt: { $round: ["$avg_stat13", 0] }},
        avg_stat14: { $toInt: { $round: ["$avg_stat14", 0] }},
        avg_stat15: { $toInt: { $round: ["$avg_stat15", 0] }},
        avg_stat16: { $toInt: { $round: ["$avg_stat16", 0] }},
        avg_stat17: { $toInt: { $round: ["$avg_stat17", 0] }},
        avg_stat18: { $toInt: { $round: ["$avg_stat18", 0] }},
        kick_avg: { $toInt: { $round: ["$kick_avg", 0] }},
        physical_avg: { $toInt: { $round: ["$physical_avg", 0] }},
        dribble_avg: { $toInt: { $round: ["$dribble_avg", 0] }},
        intelligence_avg: { $toInt: { $round: ["$intelligence_avg", 0] }},
        deffense_avg: { $toInt: { $round: ["$deffense_avg", 0] }}
      }
    }
  ];

  const result = await db.collection('stats').aggregate(pipeline).toArray();

  if (result.length > 0) {
    await db.collection('stats_result').updateOne(
      { to_userID: playerInfo },
      { $set: result[0] },
      { upsert: true }
    );
  }

  // 새로운 파이프라인으로 소수 첫째 자리까지 반올림한 평균 계산 및 저장
  const pipelinePure = [
    {
      $match: {
        "stat.to_userID": playerInfo
      }
    },
    {
      $group: {
        _id: "$stat.to_userID",
        avg_stat1: { $avg: "$stat.stat1" },
        avg_stat2: { $avg: "$stat.stat2" },
        avg_stat3: { $avg: "$stat.stat3" },
        avg_stat4: { $avg: "$stat.stat4" },
        avg_stat5: { $avg: "$stat.stat5" },
        avg_stat6: { $avg: "$stat.stat6" },
        avg_stat7: { $avg: "$stat.stat7" },
        avg_stat8: { $avg: "$stat.stat8" },
        avg_stat9: { $avg: "$stat.stat9" },
        avg_stat10: { $avg: "$stat.stat10" },
        avg_stat11: { $avg: "$stat.stat11" },
        avg_stat12: { $avg: "$stat.stat12" },
        avg_stat13: { $avg: "$stat.stat13" },
        avg_stat14: { $avg: "$stat.stat14" },
        avg_stat15: { $avg: "$stat.stat15" },
        avg_stat16: { $avg: "$stat.stat16" },
        avg_stat17: { $avg: "$stat.stat17" },
        avg_stat18: { $avg: "$stat.stat18" },
        kick_avg: { $avg: { $avg: ["$stat.stat1", "$stat.stat3", "$stat.stat5"] } },
        physical_avg: { $avg: { $avg: ["$stat.stat2", "$stat.stat4", "$stat.stat6", "$stat.stat7"] } },
        dribble_avg: { $avg: { $avg: ["$stat.stat8", "$stat.stat10", "$stat.stat12", "$stat.stat14"] } },
        intelligence_avg: { $avg: { $avg: ["$stat.stat9", "$stat.stat11", "$stat.stat13", "$stat.stat15"] } },
        deffense_avg: { $avg: { $avg: ["$stat.stat16", "$stat.stat17", "$stat.stat18"] } }
      }
    },
    {
      $project: {
        _id: 0,
        to_userID: "$_id",
        avg_stat1: { $round: ["$avg_stat1", 2] },
        avg_stat2: { $round: ["$avg_stat2", 2] },
        avg_stat3: { $round: ["$avg_stat3", 2] },
        avg_stat4: { $round: ["$avg_stat4", 2] },
        avg_stat5: { $round: ["$avg_stat5", 2] },
        avg_stat6: { $round: ["$avg_stat6", 2] },
        avg_stat7: { $round: ["$avg_stat7", 2] },
        avg_stat8: { $round: ["$avg_stat8", 2] },
        avg_stat9: { $round: ["$avg_stat9", 2] },
        avg_stat10: { $round: ["$avg_stat10", 2] },
        avg_stat11: { $round: ["$avg_stat11", 2] },
        avg_stat12: { $round: ["$avg_stat12", 2] },
        avg_stat13: { $round: ["$avg_stat13", 2] },
        avg_stat14: { $round: ["$avg_stat14", 2] },
        avg_stat15: { $round: ["$avg_stat15", 2] },
        avg_stat16: { $round: ["$avg_stat16", 2] },
        avg_stat17: { $round: ["$avg_stat17", 2] },
        avg_stat18: { $round: ["$avg_stat18", 2] },
        kick_avg: { $round: ["$kick_avg", 2] },
        physical_avg: { $round: ["$physical_avg", 2] },
        dribble_avg: { $round: ["$dribble_avg", 2] },
        intelligence_avg: { $round: ["$intelligence_avg", 2] },
        deffense_avg: { $round: ["$deffense_avg", 2] }
      }
    }
  ];

  const resultPure = await db.collection('stats').aggregate(pipelinePure).toArray();

  if (resultPure.length > 0) {
    await db.collection('stats_result_pure').updateOne(
      { to_userID: playerInfo },
      { $set: resultPure[0] },
      { upsert: true }
    );
  }
}



app.get('/ChrStat', async (req, res) => {
  try {
    let userID = req.query.userID;
    let chr = req.query.chr.split(','); // 쉼표로 구분된 문자열을 배열로 변환

    // stats_result 컬렉션에서 문서를 업데이트
    let result = await db.collection('stats_result').updateOne(
      { to_userID: userID }, // 필터: 해당 userID를 가진 문서를 찾음
      { $set: { chr: chr } }, // 업데이트: chr 필드를 새로운 값으로 설정
      { upsert: true } // 옵션: 문서가 존재하지 않으면 새로 삽입
    );

    logActivity(req.user.username, '선수 특성 부여', `- 대상: ${userID} (${chr.length}개 특성)`);
    res.redirect('back');
  } catch (error) {
    console.error('stats_result 업데이트 중 오류 발생:', error.message);
    res.status(500).send('내부 서버 오류');
  }
});



app.get('/match-result', async (req, res) => {
  let result = await db.collection('result').find().sort({ _id: -1 }).toArray();
  res.render('match-result.ejs', { result: result });
});

app.get('/gamezone-shooting', this.isLoggedIn, async (req, res, next) => {
  const timeZone = 'Asia/Seoul';
  const today = new Date();
  const currentMonth = today.toLocaleString('ko-KR', { timeZone, month: '2-digit' });
  const currentYear = today.toLocaleString('ko-KR', { timeZone, year: 'numeric' });
  let yearMonth = `${currentYear}-${currentMonth}`;

  // 쿼리로 이전 달 보기 옵션 지원 (예: ?prev=1)
  const isPrev = req.query.prev === '1';
  if (isPrev) {
    const prevDate = new Date();
    prevDate.setMonth(prevDate.getMonth() - 1);
    const prevMonth = prevDate.toLocaleString('ko-KR', { timeZone, month: '2-digit' });
    const prevYear = prevDate.toLocaleString('ko-KR', { timeZone, year: 'numeric' });
    yearMonth = `${prevYear}-${prevMonth}`;
  }

  let mvpboardDic = await db.collection('mvpboard').find().sort({ _id: -1 }).limit(1).toArray();
  let mvpboard = mvpboardDic[0].member_score;
  let ShootingScore = await db.collection('gamezone_shooting').find({ yearMonth: yearMonth }).sort({ top_score: -1 }).toArray();

  res.render('gamezone-shooting.ejs', { mvpboard: mvpboard, ShootingScore: ShootingScore, isPrev: isPrev, yearMonth: yearMonth });
});

app.post('/gamezone-shooting-extrachance', async (req, res) => {
  let username = req.user.username;
  let userShootingCount = req.body.userShootingCount;
  // console.log(userShootingCount)

  await db.collection('user').updateOne(
    { username: username },
    { $set: { shooting_count: userShootingCount } }
  );
  res.json({ success: true });
});

app.get('/gamezone-shooting-scoreboard-check', async (req, res) => {
  const timeZone = 'Asia/Seoul';
  const today = new Date();
  const currentMonth = today.toLocaleString('ko-KR', { timeZone, month: '2-digit' });
  const currentYear = today.toLocaleString('ko-KR', { timeZone, year: 'numeric' });
  const yearMonth = `${currentYear}-${currentMonth}`;

  let username = req.user.username;
  let existingUser = await db.collection('gamezone_shooting').findOne({ name: username, yearMonth: yearMonth });

  if (existingUser) {
    res.json({ top_score: existingUser.top_score });
  } else {
    res.json({ top_score: 0 });
  }
});


app.get('/gamezone-shooting-scoreboard', async (req, res) => {
  const timeZone = 'Asia/Seoul';
  const today = new Date();
  const currentMonth = today.toLocaleString('ko-KR', { timeZone, month: '2-digit' });
  const currentYear = today.toLocaleString('ko-KR', { timeZone, year: 'numeric' });
  const yearMonth = `${currentYear}-${currentMonth}`;

  let score = parseInt(req.query.score);
  let username = req.user.username;

  // 같은 월이면 update, 아니면 insert
  let result = await db.collection('gamezone_shooting').updateOne(
    { name: username, yearMonth: yearMonth },
    { $set: { top_score: score, yearMonth: yearMonth } },
    { upsert: true }
  );

  // 업데이트 후 현재 월의 1등을 확인하여 조건(점수 >= 10 && 1등) 만족 시 알림 전송
  const topList = await db.collection('gamezone_shooting')
    .find({ yearMonth: yearMonth })
    .sort({ top_score: -1 })
    .limit(1)
    .toArray();

  if (topList && topList.length > 0) {
    const topEntry = topList[0];
    if (score >= 10 && topEntry.name === username && topEntry.top_score === score) {
      sendDiscordNotification(`[${username}] 님이 승부차기에서 ${score}점으로 1위를 기록했습니다.`);
    }
  }

  logActivity(username, '승부차기 점수 저장', `- 점수: ${score}점 (${yearMonth})`);

  res.redirect('back');
});


app.post('/reset-shootinggame', async (req, res) => {
  const timeZone = 'Asia/Seoul';
  const today = new Date();
  const currentMonth = today.toLocaleString('ko-KR', { timeZone, month: '2-digit' });
  const currentYear = today.toLocaleString('ko-KR', { timeZone, year: 'numeric' });
  const yearMonth = `${currentYear}-${currentMonth}`;

  const collection = db.collection('gamezone_shooting');
  await collection.deleteMany({ yearMonth: yearMonth });
  logActivity(req.user.username, '승부차기 데이터 초기화', `- 삭제월: ${yearMonth}`);
  res.redirect('/')
})





app.get('/photo', this.isLoggedIn, async (req, res, next) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const perPage = 10;
    const skip = (page - 1) * perPage;
    
    // 전체 사진 개수 조회
    const totalPhotos = await db.collection('photo').countDocuments();
    const totalPages = Math.ceil(totalPhotos / perPage);
    
    // 현재 페이지의 사진 10개 로드
    let result = await db.collection('photo').aggregate([
      {
        $lookup: {
          from: 'photo-comment',
          localField: '_id',
          foreignField: 'parentId',
          as: 'comments'
        }
      },
      {
        $sort: {
          _id: -1
        }
      },
      {
        $skip: skip
      },
      {
        $limit: perPage
      }
    ]).toArray();
    
    res.render('photo.ejs', { 포토: result, currentPage: page, totalPages: totalPages });
  } catch (error) {
    console.error(error);
    next(error);
  }
});



app.get('/photo-post', async (req, res) => {

  res.render('photo-post.ejs');
});



app.post('/photo-post', async (req, res) => {

  const timeZone = 'Asia/Seoul';

  let Today = new Date().toLocaleDateString('ko-KR', { timeZone });
  let Time = new Date().toLocaleString('ko-KR', { timeZone });
  upload.array('img1', 10)(req, res, async (err) => {
    if (err) return res.send('업로드에러')
    try {
      if (req.body.title == '') {
        res.send('제목입력안했음')
      } else {
        const imageArray = req.files.length > 0 ? req.files.map(file => ({ filename: file.filename, location: file.location })) : [];

        await db.collection('photo').insertOne(
          {
            today: Today,
            time: Time,
            content: req.body.content,
            img: imageArray,
            user: req.user._id,
            username: req.user.username
          }
        )
        sendDiscordNotification(`[${req.user?.username || '익명'}] 님이 사진을 등록하였습니다.`);
        res.redirect('/photo')
      }
    } catch (e) {
      console.log(e)
      res.status(500).send('서버에러남')
    }
  })

})

app.get('/photo-edit/:id', async (req, res) => {
  let photoID = await db.collection('photo').findOne({ _id: new ObjectId(req.params.id) })

  res.render('photo-edit.ejs', { 포토: photoID })
})

app.put('/photo-edit', async (req, res) => {

  let result = await db.collection('photo').updateOne({ _id: new ObjectId(req.body.id) },
    {
      $set: {
        content: req.body.content
      }
    })

  res.redirect('/photo')

})

app.get('/photo-delete/:id', async (req, res) => {
  let result = await db.collection('photo').deleteOne({
    _id: new ObjectId(req.params.id)
  })
  res.redirect('/photo')
})

app.post('/photo-like/:id', async (req, res) => {
  const photoId = new ObjectId(req.params.id);
  const username = req.user.username;
  const photo = await db.collection('photo').findOne({ _id: photoId }, { projection: { likes: 1 } });

  if (!photo) {
    return res.status(404).json({ ok: false, message: '사진을 찾을 수 없습니다.' });
  }

  const likes = Array.isArray(photo.likes) ? photo.likes : [];
  const isLiked = likes.includes(username);
  const update = isLiked
    ? { $pull: { likes: username } }
    : { $addToSet: { likes: username } };

  await db.collection('photo').updateOne({ _id: photoId }, update);
  res.json({ ok: true, liked: !isLiked, likeCount: isLiked ? likes.length - 1 : likes.length + 1 });
});

app.post('/photo-comment', async (req, res) => {


  await db.collection('photo-comment').insertOne({
    content: req.body.content,
    writerId: new ObjectId(req.user._id),
    writer: req.user.username,
    parentId: new ObjectId(req.body.parentId)
  })
  sendDiscordNotification(`${req.user?.username || '익명'} 님이 사진에 댓글을 달았습니다. [${req.body.content}]`);
  res.redirect('back')
}
)

app.get('/photo-comment-delete/:id', async (req, res) => {
  let result = await db.collection('photo-comment').deleteOne({
    _id: new ObjectId(req.params.id)
  })
  res.redirect('back')
})

app.get('/video', this.isLoggedIn, async (req, res) => {
  let URL3 = await db.collection('youtubeURL').find().sort({ _id: -1 }).limit(3).toArray();

  res.render('video.ejs', { URL3:URL3 });
});

app.get('/load-more-videos', this.isLoggedIn, async (req, res) => {
  try {
    // DB에서 추가적인 비디오 데이터를 가져옴
    const newVideos = await db.collection('youtubeURL').find().sort({ _id: -1 }).skip(3).toArray();
    res.json(newVideos); // JSON 형식으로 클라이언트에 응답
  } catch (error) {
    console.error('Error loading more videos:', error);
    res.status(500).send('Failed to load more videos');
  }
});


app.get('/UploadURL', async (req, res) => {

  let result = await db.collection('youtubeURL').insertOne({
    URL: req.query.URL
  })
  logActivity(req.user.username, 'YouTube 영상 업로드', `- 비디오 ID: ${req.query.URL}`);
  res.redirect('/video')
})

app.get('/video-delete/:id', async (req, res) => {
  let result = await db.collection('youtubeURL').deleteOne({
    _id: new ObjectId(req.params.id)
  })
  res.redirect('/video')
})


// 사용자 정보를 제공하는 엔드포인트
app.get('/user', async (req, res) => {
  // 세션에서 유저 정보 가져오기 (여기서는 더미 데이터로 대체)
  const userData = {
    userId: req.user.userID
  };

  res.json(userData);
});

app.get('/mypage/:userId', async (req, res) => {

  res.render('mypage.ejs')
});